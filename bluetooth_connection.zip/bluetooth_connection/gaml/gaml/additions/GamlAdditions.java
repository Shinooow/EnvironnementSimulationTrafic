package gaml.additions;
import msi.gaml.extensions.multi_criteria.*;
import msi.gama.outputs.layers.charts.*;
import msi.gama.outputs.layers.*;
import msi.gama.outputs.*;
import msi.gama.kernel.batch.*;
import msi.gama.kernel.root.*;
import msi.gaml.architecture.weighted_tasks.*;
import msi.gaml.architecture.user.*;
import msi.gaml.architecture.reflex.*;
import msi.gaml.architecture.finite_state_machine.*;
import msi.gaml.species.*;
import msi.gama.metamodel.shape.*;
import msi.gaml.expressions.*;
import msi.gama.metamodel.topology.*;
import msi.gaml.statements.test.*;
import msi.gama.metamodel.population.*;
import msi.gama.kernel.simulation.*;
import msi.gama.kernel.model.*;
import java.util.*;
import msi.gaml.statements.draw.*;
import  msi.gama.metamodel.shape.*;
import msi.gama.common.interfaces.*;
import msi.gama.runtime.*;
import java.lang.*;
import msi.gama.metamodel.agent.*;
import msi.gaml.types.*;
import msi.gaml.compilation.*;
import msi.gaml.factories.*;
import msi.gaml.descriptions.*;
import msi.gama.util.tree.*;
import msi.gama.util.file.*;
import msi.gama.util.matrix.*;
import msi.gama.util.graph.*;
import msi.gama.util.path.*;
import msi.gama.util.*;
import msi.gama.runtime.exceptions.*;
import msi.gaml.factories.*;
import msi.gaml.statements.*;
import msi.gaml.skills.*;
import msi.gaml.variables.*;
import msi.gama.kernel.experiment.*;
import msi.gaml.operators.*;
import msi.gama.common.interfaces.*;
import msi.gama.extensions.messaging.*;
import msi.gama.metamodel.population.*;
import msi.gaml.operators.Random;
import msi.gaml.operators.Maths;
import msi.gaml.operators.Points;
import msi.gaml.operators.Spatial.Properties;
import msi.gaml.operators.System;
import static msi.gaml.operators.Cast.*;
import static msi.gaml.operators.Spatial.*;
import static msi.gama.common.interfaces.IKeyword.*;
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })

public class GamlAdditions extends AbstractGamlAdditions {
	public void initialize() throws SecurityException, NoSuchMethodException {
	initializeAction();
	initializeSkill();
}public void initializeAction() throws SecurityException, NoSuchMethodException {
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).antiClockwiseCircle(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"antiClockwiseCircle",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("antiClockwiseCircle",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).rightHalfTurn(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"rightHalfTurn",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("rightHalfTurn",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).clockwiseCircle(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"clockwiseCircle",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("clockwiseCircle",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).forwardToLeft(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"forwardToLeft",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("forwardToLeft",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).moveForward(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"moveForward",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("moveForward",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).backwardToLeft(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"backwardToLeft",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("backwardToLeft",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).slalomMove(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"slalomMove",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("slalomMove",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).connectCar(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"connectCar",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("connectCar",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).stopBeforeForward(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"stopBeforeForward",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("stopBeforeForward",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).leftHalfTurn(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"leftHalfTurn",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("leftHalfTurn",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).forwardToRight(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"forwardToRight",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("forwardToRight",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).resetWheels(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"resetWheels",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("resetWheels",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).stopBeforeBackward(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"stopBeforeBackward",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("stopBeforeBackward",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).disconnectCar(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"disconnectCar",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("disconnectCar",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).moveBackward(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"moveBackward",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("moveBackward",SC));
_action((s,a,t,v)->((bluetooth_connection.BluetoothConnection) t).backwardToRight(s),desc(PRIM,new Children(desc(ARG,NAME,"numeroCar",TYPE,"1","optional",FALSE)),NAME,"backwardToRight",TYPE,Ti(I),VIRTUAL,FALSE),bluetooth_connection.BluetoothConnection.class.getMethod("backwardToRight",SC));
}public void initializeSkill()  {
_skill("Bluetooth",bluetooth_connection.BluetoothConnection.class,AS);
}
}