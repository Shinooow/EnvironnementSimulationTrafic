package gaml.additions;
import msi.gaml.extensions.multi_criteria.*;
import msi.gama.outputs.layers.charts.*;
import msi.gama.outputs.layers.*;
import msi.gama.outputs.*;
import msi.gama.kernel.batch.*;
import msi.gama.kernel.root.*;
import msi.gaml.architecture.weighted_tasks.*;
import msi.gaml.architecture.user.*;
import msi.gaml.architecture.reflex.*;
import msi.gaml.architecture.finite_state_machine.*;
import msi.gaml.species.*;
import msi.gama.metamodel.shape.*;
import msi.gaml.expressions.*;
import msi.gama.metamodel.topology.*;
import msi.gaml.statements.test.*;
import msi.gama.metamodel.population.*;
import msi.gama.kernel.simulation.*;
import msi.gama.kernel.model.*;
import java.util.*;
import msi.gaml.statements.draw.*;
import  msi.gama.metamodel.shape.*;
import msi.gama.common.interfaces.*;
import msi.gama.runtime.*;
import java.lang.*;
import msi.gama.metamodel.agent.*;
import msi.gaml.types.*;
import msi.gaml.compilation.*;
import msi.gaml.factories.*;
import msi.gaml.descriptions.*;
import msi.gama.util.tree.*;
import msi.gama.util.file.*;
import msi.gama.util.matrix.*;
import msi.gama.util.graph.*;
import msi.gama.util.path.*;
import msi.gama.util.*;
import msi.gama.runtime.exceptions.*;
import msi.gaml.factories.*;
import msi.gaml.statements.*;
import msi.gaml.skills.*;
import msi.gaml.variables.*;
import msi.gama.kernel.experiment.*;
import msi.gaml.operators.*;
import msi.gama.common.interfaces.*;
import msi.gama.extensions.messaging.*;
import msi.gama.metamodel.population.*;
import msi.gaml.operators.Random;
import msi.gaml.operators.Maths;
import msi.gaml.operators.Points;
import msi.gaml.operators.Spatial.Properties;
import msi.gaml.operators.System;
import static msi.gaml.operators.Cast.*;
import static msi.gaml.operators.Spatial.*;
import static msi.gama.common.interfaces.IKeyword.*;
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })

public class GamlAdditions extends AbstractGamlAdditions {
	public void initialize() throws SecurityException, NoSuchMethodException {
	initializeAction();
	initializeSkill();
}public void initializeAction() throws SecurityException, NoSuchMethodException {
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).disconnectCar(s),desc(PRIM,new Children(),NAME,"disconnectCar",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("disconnectCar",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).forwardToLeft(s),desc(PRIM,new Children(),NAME,"forwardToLeft",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("forwardToLeft",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).backwardParking(s),desc(PRIM,new Children(),NAME,"backwardParking",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("backwardParking",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).clockwiseCircle(s),desc(PRIM,new Children(),NAME,"clockwiseCircle",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("clockwiseCircle",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).backwardToRight(s),desc(PRIM,new Children(),NAME,"backwardToRight",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("backwardToRight",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).moveBackward(s),desc(PRIM,new Children(),NAME,"moveBackward",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("moveBackward",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).forwardToRight(s),desc(PRIM,new Children(),NAME,"forwardToRight",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("forwardToRight",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).leftUTurn(s),desc(PRIM,new Children(),NAME,"leftUTurn",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("leftUTurn",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).connectCar(s),desc(PRIM,new Children(),NAME,"connectCar",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("connectCar",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).forwardParking(s),desc(PRIM,new Children(),NAME,"forwardParking",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("forwardParking",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).moveForward(s),desc(PRIM,new Children(),NAME,"moveForward",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("moveForward",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).antiClockwiseCircle(s),desc(PRIM,new Children(),NAME,"antiClockwiseCircle",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("antiClockwiseCircle",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).rightUTurn(s),desc(PRIM,new Children(),NAME,"rightUTurn",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("rightUTurn",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).backwardToLeft(s),desc(PRIM,new Children(),NAME,"backwardToLeft",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("backwardToLeft",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).slalom(s),desc(PRIM,new Children(),NAME,"slalom",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("slalom",SC));
_action((s,a,t,v)->((fr.irit.smac.bluetoothclient.BluetoothClient) t).parallelParking(s),desc(PRIM,new Children(),NAME,"parallelParking",TYPE,Ti(I),VIRTUAL,FALSE),fr.irit.smac.bluetoothclient.BluetoothClient.class.getMethod("parallelParking",SC));
}public void initializeSkill()  {
_skill("Bluetooth",fr.irit.smac.bluetoothclient.BluetoothClient.class,AS);
}
}