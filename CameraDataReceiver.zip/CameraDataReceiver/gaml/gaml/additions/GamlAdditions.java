package gaml.additions;
import msi.gaml.extensions.multi_criteria.*;
import msi.gama.outputs.layers.charts.*;
import msi.gama.outputs.layers.*;
import msi.gama.outputs.*;
import msi.gama.kernel.batch.*;
import msi.gama.kernel.root.*;
import msi.gaml.architecture.weighted_tasks.*;
import msi.gaml.architecture.user.*;
import msi.gaml.architecture.reflex.*;
import msi.gaml.architecture.finite_state_machine.*;
import msi.gaml.species.*;
import msi.gama.metamodel.shape.*;
import msi.gaml.expressions.*;
import msi.gama.metamodel.topology.*;
import msi.gaml.statements.test.*;
import msi.gama.metamodel.population.*;
import msi.gama.kernel.simulation.*;
import msi.gama.kernel.model.*;
import java.util.*;
import msi.gaml.statements.draw.*;
import  msi.gama.metamodel.shape.*;
import msi.gama.common.interfaces.*;
import msi.gama.runtime.*;
import java.lang.*;
import msi.gama.metamodel.agent.*;
import msi.gaml.types.*;
import msi.gaml.compilation.*;
import msi.gaml.factories.*;
import msi.gaml.descriptions.*;
import msi.gama.util.tree.*;
import msi.gama.util.file.*;
import msi.gama.util.matrix.*;
import msi.gama.util.graph.*;
import msi.gama.util.path.*;
import msi.gama.util.*;
import msi.gama.runtime.exceptions.*;
import msi.gaml.factories.*;
import msi.gaml.statements.*;
import msi.gaml.skills.*;
import msi.gaml.variables.*;
import msi.gama.kernel.experiment.*;
import msi.gaml.operators.*;
import msi.gama.common.interfaces.*;
import msi.gama.extensions.messaging.*;
import msi.gama.metamodel.population.*;
import msi.gaml.operators.Random;
import msi.gaml.operators.Maths;
import msi.gaml.operators.Points;
import msi.gaml.operators.Spatial.Properties;
import msi.gaml.operators.System;
import static msi.gaml.operators.Cast.*;
import static msi.gaml.operators.Spatial.*;
import static msi.gama.common.interfaces.IKeyword.*;
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })

public class GamlAdditions extends AbstractGamlAdditions {
	public void initialize() throws SecurityException, NoSuchMethodException {
	initializeOperator();
}public void initializeOperator() throws SecurityException, NoSuchMethodException {
_unary(S("getXCarPosition"),datareceiver.DataServer.class.getMethod("getXCarPosition",i),C(i),AI,D,F,-13,-13,-13,-13,(s,o)->datareceiver.DataServer.getXCarPosition(asInt(s,o)));
_unary(S("getYCarPosition"),datareceiver.DataServer.class.getMethod("getYCarPosition",i),C(i),AI,D,F,-13,-13,-13,-13,(s,o)->datareceiver.DataServer.getYCarPosition(asInt(s,o)));
_unary(S("getYCarSpeed"),datareceiver.DataServer.class.getMethod("getYCarSpeed",i),C(i),AI,D,F,-13,-13,-13,-13,(s,o)->datareceiver.DataServer.getYCarSpeed(asInt(s,o)));
_unary(S("getXCarSpeed"),datareceiver.DataServer.class.getMethod("getXCarSpeed",i),C(i),AI,D,F,-13,-13,-13,-13,(s,o)->datareceiver.DataServer.getXCarSpeed(asInt(s,o)));
_unary(S("socketInitialization"),datareceiver.DataServer.class.getMethod("socketInitialization",i),C(i),AI,I,F,-13,-13,-13,-13,(s,o)->datareceiver.DataServer.socketInitialization(asInt(s,o)));
}
}