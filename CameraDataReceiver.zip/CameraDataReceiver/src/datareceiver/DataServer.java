package datareceiver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

import msi.gama.precompiler.GamlAnnotations.operator;


public class DataServer {

	private static final int PORT = 6000;
	private static ServerSocket serverSocket;
	private static Socket cameraConnection;
	private static String[] formattedData;

	@operator(value = "socketInitialization")
	public static Integer socketInitialization(int nbExpectedCars) {
		try {
			serverSocket = new ServerSocket(PORT);
			System.out.println("-- Waiting for client");
			cameraConnection = serverSocket.accept();
			System.out.println("-- Client found");
		} catch (IOException e) {
			e.printStackTrace();
		}
		receiveData(nbExpectedCars);
		return 0;
	}

	public static void receiveData(int nbExpectedCars) {

		Thread taskThread = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					BufferedReader plec = new BufferedReader(new InputStreamReader(cameraConnection.getInputStream()));
					boolean socketOuvert = true;
					System.out.println("-- Waiting for data");
					while (socketOuvert) {
						try {
							String dataReceived = plec.readLine();
							if (dataReceived != null) {
								System.out.println("-- Data received\n" + dataReceived);
								if (dataReceived.equals("quit_request")) {
									socketOuvert = false;
									System.out.println("-- Connection ended");
								} else {
									formattedData = dataReceived.split("%", 10);
									if((formattedData.length/4) != nbExpectedCars) {
										System.out.println("-- !! nb detected cars is " + (formattedData.length/4) + " expected was " + nbExpectedCars);
									}
								}
							}
						} catch (SocketException se) {
							socketOuvert = false;
							System.out.println("-- Connection lost");
						}
					}
					cameraConnection.close();
					serverSocket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		});
		taskThread.start();
	}

	@operator(value = "getXCarPosition")
	public static Double getXCarPosition(int idGuidable){
		return Double.parseDouble(formattedData[4*idGuidable]);
	}
	
	@operator(value = "getYCarPosition")
	public static Double getYCarPosition(int idGuidable) {
		return Double.parseDouble(formattedData[4*idGuidable+1]);
	}
	
	@operator(value = "getXCarSpeed")
	public static Double getXCarSpeed(int idGuidable) {
		return Double.parseDouble(formattedData[4*idGuidable+2]);
	}
	
	@operator(value = "getYCarSpeed")
	public static Double getYCarSpeed(int idGuidable) {
		return Double.parseDouble(formattedData[4*idGuidable+3]);
	}
	
}
